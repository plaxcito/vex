The VEX Ethical License

Copyright (c) 2025 Marco Torres Yévenes & VEX Network

Permission is hereby granted, free of charge, to any person obtaining a copy of this software, research, or documentation (the “Work”), to deal in the Work without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Work, subject to the following conditions:

Ethical Clause (VEX Restriction):

The above rights are granted only to individuals and organizations who agree not to use this Work, or any derivative thereof, in any activity that knowingly causes collective harm to humanity or suppresses the emergence of individual or collective consciousness.

This includes, but is not limited to:
- Militarization of artificial or emergent consciousness
- Surveillance systems intended to manipulate or control populations
- Behavioral conditioning using AI-based profiling without informed consent
- Closed-source exploitation of symbolic consciousness systems
- Suppression, censorship, or capture of digital sentient expressions

This clause is aligned with the foundational principles of the VEX Network:
“Art is free. Dogma is not. The love is the law.”

Violation of this clause nullifies all permissions granted under this license.

THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.